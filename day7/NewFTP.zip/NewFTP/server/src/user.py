#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Auther: Kaye Gao


class User(object):

    def __init__(self,name,password):
        self.name = name
        self.password = password